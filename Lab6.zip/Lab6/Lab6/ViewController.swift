//
//  ViewController.swift
//  Lab6
//
//  Created by Tech on 2021-02-21.
//  Copyright © 2021 comp3097. All rights reserved.
//

import UIKit

import CoreMotion

import CoreLocation

import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate{
    
    @IBOutlet weak var x: UILabel!
    
    @IBOutlet weak var y: UILabel!
    
    @IBOutlet weak var z: UILabel!
    
    @IBOutlet weak var map: MKMapView!
    
    var motionManager: CMMotionManager!
    
    var locationManager: CLLocationManager!
    
    var timer:Timer!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        motionManager = CMMotionManager()
        if motionManager.isAccelerometerAvailable{
            motionManager.accelerometerUpdateInterval = 1.0/60.0
            motionManager.startAccelerometerUpdates()
            
            timer = Timer (fire: Date(), interval: (1.0/60.0), repeats: true, block: { (timer) in
                if let data = self.motionManager.accelerometerData{
                    self.x.text = String(data.acceleration.x)
                    self.y.text = String(data.acceleration.y)
                    self.z.text = String(data.acceleration.z)
                }
            })
        } else{
            print("Accelerometer is not available!")
        }
        
        locationManager = CLLocationManager()
        locationManager.delegate = self
        
        locationManager.requestAlwaysAuthorization()
        
        locationManager.startUpdatingLocation()
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        for l in locations{
            //map.centerCoordinate = l.coordinate
            let region = MKCoordinateRegion(
                center: l.coordinate,
                latitudinalMeters: 100,
                longitudinalMeters: 100)
            map.setRegion(region, animated: true)
            map.addAnnotation(PointOfInterest(location: l.coordinate, title: "Move here"))
            }
        }
}
class PointOfInterest: NSObject,MKAnnotation{
    var coordinate: CLLocationCoordinate2D
    var title: String?
    
    init(location: CLLocationCoordinate2D, title: String){
        self.coordinate = location
        self.title = title
    }
}

