//
//  ViewController.swift
//  LabTest
//
//  Created by Tech on 2021-02-09.
//  Copyright © 2021 gbc. All rights reserved.
//

import UIKit

import GameKit

class ViewController: UIViewController {
    
    let number = [Int](1...65)
    
    var suffleNumber = [Int]()
    
    @IBOutlet weak var firstnum: UILabel!
    @IBOutlet weak var secondnum: UILabel!
    @IBOutlet weak var thirdnum: UILabel!
    @IBOutlet weak var fourthnum: UILabel!
    @IBOutlet weak var fifthnum: UILabel!
    @IBOutlet weak var sixthnum: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func resetNumber(_ sender: UIButton) {
        firstnum.text = "-"
        secondnum.text = "-"
        thirdnum.text = "-"
        fourthnum.text = "-"
        fifthnum.text =  "-"
        sixthnum.text = "-"
    }
    
    @IBAction func drawRandomNumber(_ sender: UIButton) {
        drawNumber()
    }
    func drawNumber(){
        suffleNumber = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: number) as! [Int]
        
        firstnum.text = String(suffleNumber[0])
        secondnum.text = String(suffleNumber[1])
        thirdnum.text = String(suffleNumber[2])
        fourthnum.text = String(suffleNumber[3])
        fifthnum.text = String(suffleNumber[4])
        sixthnum.text = String(suffleNumber[5])
        }
        
    
}

