//
//  ViewController.swift
//  SampleCoreDataExample
//
//  Created by moxDroid on 2021-02-24.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    //let appDelegate = UIApplication.shared.delegate as? AppDelegate
    var allStudents: [NSManagedObject] = []
    var managedContext: NSManagedObjectContext!
    
    
    @IBOutlet weak var txtStudentId: UITextField!
    @IBOutlet weak var txtStudentName: UITextField!
    @IBOutlet weak var txtTotalMarks: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnSave(_ sender: UIButton){
        self.saveStudent()
    }
    
    func saveStudent() {
        
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        //1
        let managedContext = appDelegate.persistentContainer.viewContext
        
        //2
        let entity =
            NSEntityDescription.entity(forEntityName: "Students",
                                       in: managedContext)!
        
        //3
        let student = NSManagedObject(entity: entity, insertInto: managedContext)
        
        //4
        student.setValue(Int(txtStudentId.text!), forKey: "sid")
        student.setValue(txtStudentName.text!, forKey: "snm")
        student.setValue(Double(txtTotalMarks.text!), forKey: "total")
        
        
        //5
        do {
            try managedContext.save()
            showStatusAlert(title: "Success", message: "Record Saved Successfully")
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
            showStatusAlert(title: "Error", message: "Error while inserting record")
        }
    
    }
    
    @IBAction func btnFetchStudents(_ sender: UIButton){
        self.fetchStudent()
    }
    
    func fetchStudent() {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
    
        //1
        let managedContext = appDelegate.persistentContainer.viewContext
        
        
        //2
        let fetchRequest =
            NSFetchRequest<NSManagedObject>(entityName: "Students")
        
        //Sorting By name
        let nameSortDescriptor = NSSortDescriptor(key: "snm", ascending: false)
        let idSortDescriptor = NSSortDescriptor(key: "sid", ascending: false)
        
        fetchRequest.sortDescriptors = [nameSortDescriptor]
        
        //Where Clause
        let snm = "Pritesh Patel"
        let sid = 2
        let predicateName = NSPredicate(format: "snm = %@", snm)
        let predicateStudentID = NSPredicate(format: "sid = %@", NSNumber(value: sid))
        //fetchRequest.predicate = predicateName
        
        //AND
        //fetchRequest.predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [predicateName, predicateStudentID])
        //fetchRequest.predicate = NSCompoundPredicate.init(type: .and, subpredicates: [predicateName, predicateStudentID])
        
        //OR
        fetchRequest.predicate = NSCompoundPredicate.init(type: .or, subpredicates: [predicateName, predicateStudentID])
        
        //3
        do {
            allStudents = try managedContext.fetch(fetchRequest)
            
            for m in allStudents
            {
                let s = m as! Students
                print(s.sid, s.snm!, s.total)
            }
            
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
    }
    
    func deleteStudent()  {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
    
        //1
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let student = allStudents[0] //Delete record
        managedContext.delete(student)
    }
    
    func updateStudent()  {
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
    
        //1
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let student = allStudents[0] //Delete record
        student.setValue("New Name", forKey: "snm")
        //Update
        do {
            try managedContext.save()
            showStatusAlert(title: "Success", message: "Record Updated Successfully")
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
            showStatusAlert(title: "Error", message: "Error while updating record")
        }
    }
    
    func showStatusAlert(title: String, message: String)
    {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) { (result : UIAlertAction) -> Void in
        }
        
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }

}

