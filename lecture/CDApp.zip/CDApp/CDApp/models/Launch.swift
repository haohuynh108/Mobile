//
//  Launch.swift
//  CDApp
//
//  Created by Pritesh Patel on 2021-01-13.
//

import Foundation

struct Launch: Codable{
    var flightName : String
    var success : Bool
    var statusDetails : String
    var failureReason : String
    
    enum CodingKeys: String, CodingKey{
        case flightName = "name"
        case success = "success"
        case statusDetails = "details"
        case failureReason = "reason"
        case failures = "failures"
    }
    
    init() {
        flightName = ""
        success = false
        statusDetails = ""
        failureReason = ""
    }
    
    init(from decoder: Decoder) throws {
        let response = try decoder.container(keyedBy: CodingKeys.self)
        
        self.flightName = try response.decodeIfPresent(String.self, forKey: .flightName) ?? "Unavailable"
        
        self.success = try response.decodeIfPresent(Bool.self, forKey: .success) ?? false
        
//        print(#function, "Success \(self.success)")
        self.statusDetails = try response.decodeIfPresent(String.self, forKey: .statusDetails) ?? "Unavailable"
        
        if (!self.success){
            let failureContainer = try response.decodeIfPresent([Failure].self,forKey: .failures)
            
//            print(#function, "failureContainer : \(failureContainer)")
            self.failureReason = failureContainer?.first?.reason ?? "Unavailable"
        }else{
            self.failureReason = "Unavailable"
        }
    }
    
    func encode(to encoder: Encoder) throws {
        // nothing to encode
    }
    
}

struct Failure : Codable {
    let reason : String
    
    enum CodingKeys: String, CodingKey {
        case reason = "reason"
    }
    
    init(from decoder: Decoder) throws {
        let response = try decoder.container(keyedBy: CodingKeys.self)
        self.reason = try response.decodeIfPresent(String.self, forKey: .reason) ?? "Unavailable"
    }
    
    func encode(to encoder: Encoder) throws {
        //nothing to encode
    }
}
