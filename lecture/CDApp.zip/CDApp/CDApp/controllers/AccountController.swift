//
//  AccountController.swift
//  CDApp
//
//  Created by Pritesh Patel on 2021-01-11.
//

import Foundation
import CoreData
import UIKit

class AccountController {
    private var moc : NSManagedObjectContext
    
    init(){
        self.moc = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    }
    
    func insertAccount(email: String, password: String) -> AccountStatus{
        do{
            let newAccount = NSEntityDescription.insertNewObject(forEntityName: "Account", into: moc) as! Account
            
            newAccount.dateCreated = Date()
            newAccount.isActive = true
            newAccount.email = email
            newAccount.password = password
            
            let newUser = NSEntityDescription.insertNewObject(forEntityName: "User", into: moc) as! User
            newUser.email = email
            newUser.firstname = "unknown"
            newUser.lastname = "unknown"
            newUser.birthdate = Date()
            
            try moc.save()
            
            print(#function, "Account successfully created")
            return AccountStatus.INSERT_SUCCESS
            
        }catch let error as NSError{
            if error.code == 133021{
                print(#function, "Account already exists")
                return AccountStatus.USER_EXISTS
            }else{
                print(#function, "Something went wrong. Couldn't create account")
                print(#function, error, error.localizedDescription)
                return AccountStatus.INSERT_FAILURE
            }
        }
    }
    
    func getAllAccounts(){
        let fetchRequest = NSFetchRequest<Account>(entityName: "Account")
        
        do{
            let result = try moc.fetch(fetchRequest)
            let accountList = result as [Account]
            
            for account in accountList{
                print("Email \(account.email) Password \(account.password) DateCreated \(account.dateCreated) isActive \(account.isActive)")
            }
            
        }catch let error{
            print(#function, "Couldn't fetch records", error.localizedDescription)
        }
    }
    
    func validateAccount(email: String, password: String) -> Bool{
        //search for record
        //check if the account is active
        
        let accountToValidate = self.searchAccount(email: email)
        
        if accountToValidate != nil{
            if (accountToValidate!.password == password && accountToValidate!.isActive){
                return true
            }
        }
        
        return false
    }
    
    func searchAccount(email: String) -> Account?{
        let fetchRequest = NSFetchRequest<Account>(entityName: "Account")
        
        let predicate = NSPredicate(format: "email == %@", email)
        fetchRequest.predicate = predicate
        
        do{
            let result = try moc.fetch(fetchRequest).first
            
            if result != nil{
                print(#function, "Matching account found with email \(email)")
                
                let account = result as! Account
                return account
            }
        }catch let error{
            print(#function, error.localizedDescription)
        }
        
        print(#function, "No Account found with \(email)")
        return nil
    }
    
    func deactivateAccount(email: String){
        let accountToDelete = self.searchAccount(email: email)
        
        if accountToDelete != nil{
            do{
                //to delete the record from database
//                moc.delete(accountToDelete!)
                
                //updating the record
                accountToDelete?.isActive = false
                
                try moc.save()
            }catch let error{
                print(#function, "Cannot delete account" ,error)
            }
        }
    }
}

enum AccountStatus{
    case INSERT_SUCCESS
    case USER_EXISTS
    case INSERT_FAILURE
}
