//
//  UserController.swift
//  CDApp
//
//  Created by Pritesh Patel on 2021-01-12.
//

import Foundation
import CoreData
import UIKit

class UserController {
    private var moc : NSManagedObjectContext
    
    init() {
        self.moc = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    }
    
    func saveProfile(firstname: String, lastname: String, birthdate: Date){
        let email = UserDefaults.standard.value(forKey: "jk.useremail") as! String
        
        let profileToUpdate = self.searchProfile(email: email)
        
        if profileToUpdate != nil{
            do{
                profileToUpdate!.firstname = firstname
                profileToUpdate!.lastname = lastname
                profileToUpdate!.birthdate = birthdate
                
                try moc.save()
                print(#function, "Profile updates successfully")
            }catch let error{
                print(#function, "Unable to update profile")
                print(#function, error)
            }
        }
    }
    
    func getAllProfiles(){
        let fetchRequest = NSFetchRequest<User>(entityName: "User")
        
        do{
            let result = try moc.fetch(fetchRequest)
            let profileList = result as [User]
            
            for profile in profileList{
                print(#function, "email \(profile.email) firstname: \(profile.firstname) lastname \(profile.lastname) birthdate: \(profile.birthdate)")
            }
            
        }catch let error{
            print(#function, "Unable to fetch profiles")
            print(#function, error)
        }
    }
    
    func searchProfile(email: String) -> User?{
        let fetchRequest = NSFetchRequest<User>(entityName: "User")
        let predicate = NSPredicate(format: "email = %@", email)
        fetchRequest.predicate = predicate
        
        do{
            let result = try moc.fetch(fetchRequest)
            
            if let matchingUser = result.first! as? User{
                return matchingUser
            }
        }catch let error{
            print(#function, "No matching profile found")
            print(#function, error)
        }
        
        return nil
    }
}
