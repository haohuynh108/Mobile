//
//  LanchesFetcher.swift
//  CDApp
//
//  Created by Pritesh Patel on 2021-01-13.
//

import Foundation

class LaunchesFetcher{
    var apiURL = "https://api.spacexdata.com/v4/launches"
    
    func fetchDataFromAPI(onSuccess: @escaping([Launch]?) -> Void, onError: @escaping(String) -> Void){
        
        guard let api = URL(string: apiURL) else {
            onError("Invalid URL. Cannot fetch the data.")
            return
        }
        
        URLSession.shared.dataTask(with: api){(data: Data?, response: URLResponse?, error: Error?) in
            
            if let err = error{
                print(#function, err)
                onError("Error occured : \(err.localizedDescription)")
            }else{
                //received data or response
                
                //decode
                DispatchQueue.global().async {
                    do{
                        if let jsonData = data{
                            let decoder = JSONDecoder()
                            
                            //use this if API response is an array of JSON objects
                            let decodedLaunchList = try decoder.decode([Launch].self, from: jsonData)
                            
                            //use this if API response is a JSON object
//                            let decodedLaunchList = try decoder.decode(Launch.self, from: jsonData)
                            
                            onSuccess(decodedLaunchList)
                        }else{
                            print(#function, "No JSON data received")
                            onError("No JSON data received")
                        }
                    }catch let error{
                        print(#function, error)
                        onError("Error occurred decoding the data \(error.localizedDescription)")
                    }
                }
            }
        }.resume()
    }
}
