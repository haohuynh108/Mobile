//
//  CreateAccountViewController.swift
//  CDApp
//
//  Created by Pritesh Patel on 2021-01-11.
//

import UIKit

class CreateAccountViewController: UIViewController {

    @IBOutlet var email: UITextField!
    @IBOutlet var password: UITextField!
    @IBOutlet var confirmPassword: UITextField!
    
    let accountController = AccountController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func createAccount(){
        //add data validation for inputs and check for empty fields
        
        let pwd = self.password.text
        let confirmPwd = self.confirmPassword.text
        
        if (pwd == confirmPwd){
            let emailAdd = self.email.text ?? "unknown"
            
            let insertionStatus = self.accountController.insertAccount(email: emailAdd, password: pwd!)
            
            switch insertionStatus {
            case .INSERT_SUCCESS:
                print(#function, "account created")
                self.navigationController?.popViewController(animated: true)
            case .USER_EXISTS:
                //exercise: show an alert and provide the options to recover password or activate account
                print(#function, "User with same email already exists")
            case .INSERT_FAILURE:
                print(#function, "Somethign went wrong. Sorry for inconvenience")
            }
        }else{
            print(#function, "both passwords must be same.")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
