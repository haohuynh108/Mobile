//
//  ProfileViewController.swift
//  CDApp
//
//  Created by Pritesh Patel on 2021-01-12.
//

import UIKit

class ProfileViewController: UIViewController {
    
    @IBOutlet var txtFirstname: UITextField!
    @IBOutlet var txtLastname: UITextField!
    @IBOutlet var dpDOB: UIDatePicker!
    
    let email = UserDefaults.standard.value(forKey: "jk.useremail") as! String
    let userController = UserController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.userController.getAllProfiles()
        self.loadInitialProfile()
    }
    
    @IBAction func deactivateAccount(){
        let alert = UIAlertController(title: "Caution", message: "Are you sure want to deactivate the account?", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        
        alert.addAction(UIAlertAction(title: "Deactivate", style: .destructive, handler: {_ in
        
            let accountController = AccountController()
            accountController.deactivateAccount(email: self.email)
            
            UserDefaults.standard.removeObject(forKey: "jk.useremail")
            
            self.navigationController?.popToRootViewController(animated: true)
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func saveProfile(){
        if (txtFirstname.text != nil && txtLastname.text != nil){
            let fname = self.txtFirstname.text!
            let lname = self.txtLastname.text!
            let birthdate = self.dpDOB.date
            
            self.userController.saveProfile(firstname: fname, lastname: lname, birthdate: birthdate)
        }
    }
    
    func loadInitialProfile(){
        let currentUser = self.userController.searchProfile(email: email)
        
        if currentUser != nil{
            self.txtFirstname.text = currentUser!.firstname
            self.txtLastname.text = currentUser!.lastname
            self.dpDOB.date = currentUser!.birthdate!
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
