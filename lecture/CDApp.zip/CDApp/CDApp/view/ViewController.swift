//
//  ViewController.swift
//  CDApp
//
//  Created by Pritesh Patel on 2021-01-11.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var email: UITextField!
    @IBOutlet var password: UITextField!
    
    let accountController = AccountController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        accountController.getAllAccounts()
    }

    @IBAction func signIn(){
        print(#function, "Sign in clicked")
        if (email.text != nil && password.text != nil){
            if (self.accountController.validateAccount(email: email.text!, password: password.text!)){
                print(#function, "Login successful")
                self.loginSuccessful()
                
            }else{
                let alert = UIAlertController(title: "Login Unsuccessful", message: "Incorrect email and/or password. Try again!", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "default action"), style: .default, handler: nil))
                
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    func loginSuccessful(){
        UserDefaults.standard.setValue(email.text!, forKey: "jk.useremail")
        
        let alert = UIAlertController(title: "Login successful", message: "You have successfully logged in.", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "default action"), style: .default, handler: {_ in
            print(#function, "Navigating to the home screen")
            
            let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
            let tabContainer = storyboard.instantiateViewController(withIdentifier: "TabContainer")
            
            tabContainer.navigationItem.hidesBackButton = true
            tabContainer.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "SignOut", style: .plain, target: self, action: #selector(self.signout))
            
            self.navigationController?.pushViewController(tabContainer, animated: true)
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    @objc
    func signout(){
        self.navigationController?.popToRootViewController(animated : true)
    }
}

