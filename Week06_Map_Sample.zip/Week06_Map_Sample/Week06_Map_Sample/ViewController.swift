//
//  ViewController.swift
//  Week06_Map_Sample
//
//  Created by moxDroid on 2021-02-17.
//

import UIKit
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, UISearchBarDelegate {
    
    @IBOutlet weak var myMapView: MKMapView!
    
    var locationManager = CLLocationManager()
    let location = CLLocation(latitude: 43.6532, longitude: -79.3832)
    let regionRadius: CLLocationDistance = 1000
    
    //Adding Search Bar
    var searchController: UISearchController!
    
    var localSearch: MKLocalSearch!
    var localSearchRequest: MKLocalSearch.Request!
    var pointAnnotation:MKPointAnnotation!
    var pinAnnotationView:MKPinAnnotationView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.showSearchView()
        
        self.setMapView()
        self.centerMapOnLocation(location: location)
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.delegate = self
        
        DispatchQueue.main.async {
            self.locationManager.startUpdatingLocation()
        }
        
        //Search GBC
        self.searchMyLocation(searchText: "George Brown College, Toronto")
    }
    
    func searchMyLocation(searchText: String){
        
        localSearchRequest = MKLocalSearch.Request()
        localSearchRequest.naturalLanguageQuery = searchText
       
        localSearch = MKLocalSearch(request: localSearchRequest)
        
        localSearch.start(completionHandler: { (searchResponse, error) in
            if(searchResponse != nil){
                self.pointAnnotation = MKPointAnnotation()
                self.pointAnnotation.title = searchText
                self.pointAnnotation.coordinate = CLLocationCoordinate2D(latitude: searchResponse!.boundingRegion.center.latitude, longitude:     searchResponse!.boundingRegion.center.longitude)
                
                
                self.pinAnnotationView = MKPinAnnotationView(annotation: self.pointAnnotation, reuseIdentifier: nil)
                self.myMapView.centerCoordinate = self.pointAnnotation.coordinate
                self.pinAnnotationView.pinTintColor = UIColor.green
                self.pinAnnotationView.image = UIImage(contentsOfFile: "home")
                self.myMapView.addAnnotation(self.pinAnnotationView.annotation!)
            
            }
        })
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        print("TEST")
    }
    
    func showSearchView(){
        searchController = UISearchController(searchResultsController: nil)
        searchController.hidesNavigationBarDuringPresentation = true
        searchController.searchBar.delegate = self
        present(searchController, animated: true, completion: nil)
    }
    
    func setMapView(){
        myMapView.showsUserLocation = true
        myMapView.isPitchEnabled = true
        myMapView.mapType = MKMapType.standard
        myMapView.isZoomEnabled = true
        myMapView.isScrollEnabled = true
    }
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegion(center: location.coordinate,
                                                  latitudinalMeters: regionRadius * 2.0, longitudinalMeters: regionRadius * 2.0)
        myMapView.setRegion(coordinateRegion, animated: true)
        
        // Drop a pin at user's Current Location
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude);
        myAnnotation.title = "Toronto"
        myAnnotation.subtitle = "City Hall, King St. W"
        myMapView.addAnnotation(myAnnotation)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations.last)
        self.centerMapOnLocation(location: locations[0] as CLLocation)
    }


}

